## Setup cmake
```bash
mkdir bin
cd bin
cmake ..
```

## Buid
```bash
make
```

## Run
1. Add your API keys to the clients
2. Run the examples:
```bash
./src/example/rest_test
./src/example/ws_test
```
